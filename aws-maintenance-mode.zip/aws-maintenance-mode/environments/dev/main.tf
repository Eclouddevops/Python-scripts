###############################################################################
# Dev Environment - Single Account Maintenance Mode (For Testing)
#
# Use this to test the maintenance mode module in a single AWS account
# before deploying to production with cross-account setup.
###############################################################################

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }

  # For local testing, you can use local backend
  # For team usage, switch to S3 backend
  # backend "s3" {
  #   bucket         = "your-terraform-state-bucket"
  #   key            = "maintenance-mode/dev/terraform.tfstate"
  #   region         = "us-east-1"
  #   encrypt        = true
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "dev"
    }
  }
}

###############################################################################
# Module: WAF Maintenance Mode (REGIONAL - for ALB/API Gateway)
###############################################################################

module "maintenance_regional" {
  source = "../../modules/waf"

  maintenance_enabled = var.maintenance_enabled
  project_name        = var.project_name
  environment         = "dev"

  waf_scope           = "REGIONAL"
  internal_ipv4_cidrs = var.internal_ipv4_cidrs
  internal_ipv6_cidrs = var.internal_ipv6_cidrs

  alb_arns         = var.alb_arns
  api_gateway_arns = var.api_gateway_arns

  maintenance_page_title   = var.maintenance_page_title
  maintenance_page_message = var.maintenance_page_message
  maintenance_page_eta     = var.maintenance_page_eta

  bypass_header_name  = var.bypass_header_name
  bypass_header_value = var.bypass_header_value

  rate_limit_enabled = var.rate_limit_enabled
  rate_limit_value   = var.rate_limit_value

  tags = var.tags
}

###############################################################################
# Outputs
###############################################################################

output "maintenance_enabled" {
  description = "Current maintenance mode state"
  value       = var.maintenance_enabled
}

output "web_acl_arn" {
  description = "WAF Web ACL ARN"
  value       = module.maintenance_regional.web_acl_arn
}

output "web_acl_id" {
  description = "WAF Web ACL ID"
  value       = module.maintenance_regional.web_acl_id
}

output "ip_set_arn" {
  description = "Internal team IP set ARN"
  value       = module.maintenance_regional.ipv4_ip_set_arn
}
