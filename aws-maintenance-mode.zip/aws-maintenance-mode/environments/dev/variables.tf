###############################################################################
# Dev Environment Variables
###############################################################################

variable "maintenance_enabled" {
  type        = bool
  default     = false
  description = "Toggle maintenance mode ON/OFF"
}

variable "project_name" {
  type        = string
  default     = "maintenance-mode"
  description = "Project name"
}

variable "aws_region" {
  type        = string
  default     = "us-east-1"
  description = "AWS region"
}

variable "internal_ipv4_cidrs" {
  type        = list(string)
  default     = ["0.0.0.0/32"] # Replace with your actual IP
  description = "Internal team IPv4 CIDR ranges"
}

variable "internal_ipv6_cidrs" {
  type        = list(string)
  default     = []
  description = "Internal team IPv6 CIDR ranges"
}

variable "alb_arns" {
  type        = list(string)
  default     = []
  description = "ALB ARNs to protect"
}

variable "api_gateway_arns" {
  type        = list(string)
  default     = []
  description = "API Gateway stage ARNs to protect"
}

variable "maintenance_page_title" {
  type        = string
  default     = "Scheduled Maintenance (DEV)"
  description = "Maintenance page title"
}

variable "maintenance_page_message" {
  type        = string
  default     = "Dev environment is under maintenance."
  description = "Maintenance page message"
}

variable "maintenance_page_eta" {
  type        = string
  default     = "Back soon."
  description = "ETA message"
}

variable "bypass_header_name" {
  type        = string
  default     = "X-Maintenance-Bypass"
  description = "Bypass header name"
}

variable "bypass_header_value" {
  type        = string
  default     = "dev-bypass-token"
  sensitive   = true
  description = "Bypass header value"
}

variable "rate_limit_enabled" {
  type        = bool
  default     = false
  description = "Enable rate limiting"
}

variable "rate_limit_value" {
  type        = number
  default     = 2000
  description = "Rate limit value"
}

variable "tags" {
  type        = map(string)
  default     = { Environment = "dev" }
  description = "Tags"
}
