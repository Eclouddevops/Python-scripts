###############################################################################
# Multi-Account Provider Configuration
#
# This file configures AWS providers for cross-account deployment.
# Each account has its own provider alias that assumes a role in that account.
#
# Prerequisites:
# - A "MaintenanceModeRole" IAM role must exist in each target account
# - The role must trust the central/management account
# - The role must have permissions to manage WAF, SSM, and CloudWatch
###############################################################################

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }

  # Remote state - update with your S3 bucket
  backend "s3" {
    bucket         = "your-terraform-state-bucket"
    key            = "maintenance-mode/prod/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-state-lock"
    encrypt        = true
  }
}

###############################################################################
# Default Provider (Central/Management Account)
###############################################################################

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "production"
    }
  }
}

###############################################################################
# Provider for CloudFront Account (WAF CLOUDFRONT scope must be us-east-1)
###############################################################################

provider "aws" {
  alias  = "cloudfront_account"
  region = "us-east-1" # Required for CloudFront WAF

  assume_role {
    role_arn     = "arn:aws:iam::${var.cloudfront_account_id}:role/${var.cross_account_role_name}"
    session_name = "maintenance-mode-terraform"
    external_id  = var.external_id
  }

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "production"
    }
  }
}

###############################################################################
# Provider for ECS Account (ALB - REGIONAL scope)
###############################################################################

provider "aws" {
  alias  = "ecs_account"
  region = var.aws_region

  assume_role {
    role_arn     = "arn:aws:iam::${var.ecs_account_id}:role/${var.cross_account_role_name}"
    session_name = "maintenance-mode-terraform"
    external_id  = var.external_id
  }

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "production"
    }
  }
}

###############################################################################
# Provider for Lambda Account (API Gateway - REGIONAL scope)
###############################################################################

provider "aws" {
  alias  = "lambda_account"
  region = var.aws_region

  assume_role {
    role_arn     = "arn:aws:iam::${var.lambda_account_id}:role/${var.cross_account_role_name}"
    session_name = "maintenance-mode-terraform"
    external_id  = var.external_id
  }

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "production"
    }
  }
}

###############################################################################
# Provider for EC2 Account (ALB - REGIONAL scope)
###############################################################################

provider "aws" {
  alias  = "ec2_account"
  region = var.aws_region

  assume_role {
    role_arn     = "arn:aws:iam::${var.ec2_account_id}:role/${var.cross_account_role_name}"
    session_name = "maintenance-mode-terraform"
    external_id  = var.external_id
  }

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Project     = "maintenance-mode"
      Environment = "production"
    }
  }
}
