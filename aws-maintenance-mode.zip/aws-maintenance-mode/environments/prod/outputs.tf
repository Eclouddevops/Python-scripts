###############################################################################
# Production Environment Outputs
###############################################################################

output "maintenance_enabled" {
  description = "Current maintenance mode state"
  value       = var.maintenance_enabled
}

output "cloudfront_waf_acl_arn" {
  description = "WAF Web ACL ARN for CloudFront account"
  value       = module.maintenance_cloudfront.web_acl_arn
}

output "ecs_waf_acl_arn" {
  description = "WAF Web ACL ARN for ECS account"
  value       = module.maintenance_ecs.web_acl_arn
}

output "lambda_waf_acl_arn" {
  description = "WAF Web ACL ARN for Lambda account"
  value       = module.maintenance_lambda.web_acl_arn
}

output "ec2_waf_acl_arn" {
  description = "WAF Web ACL ARN for EC2 account"
  value       = module.maintenance_ec2.web_acl_arn
}

output "summary" {
  description = "Summary of maintenance mode deployment"
  value = {
    status = var.maintenance_enabled ? "MAINTENANCE MODE ACTIVE" : "Normal Operation"
    protected_accounts = {
      cloudfront = var.cloudfront_account_id
      ecs        = var.ecs_account_id
      lambda     = var.lambda_account_id
      ec2        = var.ec2_account_id
    }
    whitelisted_ips = var.internal_ipv4_cidrs
  }
}
