###############################################################################
# Production Environment Variables
###############################################################################

# --- Core Settings ---

variable "maintenance_enabled" {
  type        = bool
  default     = false
  description = "Toggle maintenance mode ON/OFF across all accounts"
}

variable "project_name" {
  type        = string
  default     = "maintenance-mode"
  description = "Project name for resource naming"
}

variable "aws_region" {
  type        = string
  default     = "us-east-1"
  description = "Primary AWS region for regional resources"
}

# --- Account IDs ---

variable "cloudfront_account_id" {
  type        = string
  description = "AWS Account ID where CloudFront distributions are hosted"
}

variable "ecs_account_id" {
  type        = string
  description = "AWS Account ID where ECS services are hosted"
}

variable "lambda_account_id" {
  type        = string
  description = "AWS Account ID where Lambda functions are hosted"
}

variable "ec2_account_id" {
  type        = string
  description = "AWS Account ID where EC2 instances are hosted"
}

variable "cross_account_role_name" {
  type        = string
  default     = "MaintenanceModeRole"
  description = "Name of the IAM role to assume in each target account"
}

variable "external_id" {
  type        = string
  default     = ""
  description = "External ID for cross-account role assumption (optional but recommended)"
}

# --- Internal Team IPs ---

variable "internal_ipv4_cidrs" {
  type        = list(string)
  description = "IPv4 CIDR ranges for internal team (office, VPN)"
  default     = []
}

variable "internal_ipv6_cidrs" {
  type        = list(string)
  description = "IPv6 CIDR ranges for internal team"
  default     = []
}

# --- Resource ARNs ---

variable "cloudfront_distribution_arns" {
  type        = list(string)
  default     = []
  description = "CloudFront distribution ARNs to protect"
}

variable "ecs_alb_arns" {
  type        = list(string)
  default     = []
  description = "ALB ARNs in the ECS account to protect"
}

variable "lambda_api_gateway_arns" {
  type        = list(string)
  default     = []
  description = "API Gateway stage ARNs in the Lambda account to protect"
}

variable "ec2_alb_arns" {
  type        = list(string)
  default     = []
  description = "ALB ARNs in the EC2 account to protect"
}

# --- Maintenance Page Customization ---

variable "maintenance_page_title" {
  type        = string
  default     = "Scheduled Maintenance"
  description = "Title for the maintenance page"
}

variable "maintenance_page_message" {
  type        = string
  default     = "We're performing scheduled maintenance to improve your experience. We apologize for the inconvenience and will be back shortly."
  description = "Message body for the maintenance page"
}

variable "maintenance_page_eta" {
  type        = string
  default     = "We expect to be back within 2 hours."
  description = "ETA message shown on the maintenance page"
}

# --- Bypass Configuration ---

variable "bypass_header_name" {
  type        = string
  default     = "X-Maintenance-Bypass"
  description = "Header name for maintenance bypass"
}

variable "bypass_header_value" {
  type        = string
  default     = ""
  sensitive   = true
  description = "Secret header value for maintenance bypass"
}

# --- Rate Limiting ---

variable "rate_limit_enabled" {
  type        = bool
  default     = false
  description = "Enable rate limiting during maintenance"
}

variable "rate_limit_value" {
  type        = number
  default     = 2000
  description = "Max requests per 5-minute window per IP"
}

# --- Tags ---

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Additional tags for all resources"
}
