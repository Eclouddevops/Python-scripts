###############################################################################
# Production Environment - Maintenance Mode Deployment
#
# This deploys maintenance mode WAF across multiple AWS accounts:
# - CloudFront account (CLOUDFRONT scope)
# - ECS account (REGIONAL scope, attached to ALBs)
# - Lambda account (REGIONAL scope, attached to API Gateways)
# - EC2 account (REGIONAL scope, attached to ALBs)
###############################################################################

###############################################################################
# Module: CloudFront Account WAF (Global/CloudFront scope)
###############################################################################

module "maintenance_cloudfront" {
  source = "../../modules/waf"

  providers = {
    aws = aws.cloudfront_account
  }

  maintenance_enabled = var.maintenance_enabled
  project_name        = var.project_name
  environment         = "production"

  waf_scope           = "CLOUDFRONT"
  internal_ipv4_cidrs = var.internal_ipv4_cidrs
  internal_ipv6_cidrs = var.internal_ipv6_cidrs

  cloudfront_distribution_arns = var.cloudfront_distribution_arns

  maintenance_page_title   = var.maintenance_page_title
  maintenance_page_message = var.maintenance_page_message
  maintenance_page_eta     = var.maintenance_page_eta

  bypass_header_name  = var.bypass_header_name
  bypass_header_value = var.bypass_header_value

  rate_limit_enabled = var.rate_limit_enabled
  rate_limit_value   = var.rate_limit_value

  tags = var.tags
}

###############################################################################
# Module: ECS Account WAF (Regional scope - ALBs)
###############################################################################

module "maintenance_ecs" {
  source = "../../modules/waf"

  providers = {
    aws = aws.ecs_account
  }

  maintenance_enabled = var.maintenance_enabled
  project_name        = var.project_name
  environment         = "production"

  waf_scope           = "REGIONAL"
  internal_ipv4_cidrs = var.internal_ipv4_cidrs
  internal_ipv6_cidrs = var.internal_ipv6_cidrs

  alb_arns = var.ecs_alb_arns

  maintenance_page_title   = var.maintenance_page_title
  maintenance_page_message = var.maintenance_page_message
  maintenance_page_eta     = var.maintenance_page_eta

  bypass_header_name  = var.bypass_header_name
  bypass_header_value = var.bypass_header_value

  rate_limit_enabled = var.rate_limit_enabled
  rate_limit_value   = var.rate_limit_value

  tags = var.tags
}

###############################################################################
# Module: Lambda Account WAF (Regional scope - API Gateways)
###############################################################################

module "maintenance_lambda" {
  source = "../../modules/waf"

  providers = {
    aws = aws.lambda_account
  }

  maintenance_enabled = var.maintenance_enabled
  project_name        = var.project_name
  environment         = "production"

  waf_scope           = "REGIONAL"
  internal_ipv4_cidrs = var.internal_ipv4_cidrs
  internal_ipv6_cidrs = var.internal_ipv6_cidrs

  api_gateway_arns = var.lambda_api_gateway_arns

  maintenance_page_title   = var.maintenance_page_title
  maintenance_page_message = var.maintenance_page_message
  maintenance_page_eta     = var.maintenance_page_eta

  bypass_header_name  = var.bypass_header_name
  bypass_header_value = var.bypass_header_value

  rate_limit_enabled = var.rate_limit_enabled
  rate_limit_value   = var.rate_limit_value

  tags = var.tags
}

###############################################################################
# Module: EC2 Account WAF (Regional scope - ALBs)
###############################################################################

module "maintenance_ec2" {
  source = "../../modules/waf"

  providers = {
    aws = aws.ec2_account
  }

  maintenance_enabled = var.maintenance_enabled
  project_name        = var.project_name
  environment         = "production"

  waf_scope           = "REGIONAL"
  internal_ipv4_cidrs = var.internal_ipv4_cidrs
  internal_ipv6_cidrs = var.internal_ipv6_cidrs

  alb_arns = var.ec2_alb_arns

  maintenance_page_title   = var.maintenance_page_title
  maintenance_page_message = var.maintenance_page_message
  maintenance_page_eta     = var.maintenance_page_eta

  bypass_header_name  = var.bypass_header_name
  bypass_header_value = var.bypass_header_value

  rate_limit_enabled = var.rate_limit_enabled
  rate_limit_value   = var.rate_limit_value

  tags = var.tags
}
