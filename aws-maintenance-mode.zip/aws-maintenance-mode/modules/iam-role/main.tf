###############################################################################
# IAM Role Module - Deploy in each target account
#
# This creates the IAM role that the central account assumes
# to manage WAF maintenance mode in this account.
#
# Deploy this ONCE in each target account (CloudFront, ECS, Lambda, EC2).
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

variable "central_account_id" {
  type        = string
  description = "The AWS Account ID of the central/management account that will assume this role"
}

variable "role_name" {
  type        = string
  default     = "MaintenanceModeRole"
  description = "Name of the IAM role"
}

variable "external_id" {
  type        = string
  default     = ""
  description = "External ID for additional security (optional but recommended)"
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to apply to the role"
}

###############################################################################
# IAM Role - Trusted by Central Account
###############################################################################

resource "aws_iam_role" "maintenance_mode" {
  name        = var.role_name
  description = "Allows the central account to manage WAF maintenance mode in this account"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowCentralAccountAssume"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${var.central_account_id}:root"
        }
        Action = "sts:AssumeRole"
        Condition = var.external_id != "" ? {
          StringEquals = {
            "sts:ExternalId" = var.external_id
          }
        } : {}
      }
    ]
  })

  tags = merge(
    {
      Purpose   = "maintenance-mode"
      ManagedBy = "terraform"
    },
    var.tags
  )
}

###############################################################################
# IAM Policy - Permissions for WAF, SSM, CloudWatch management
###############################################################################

resource "aws_iam_role_policy" "maintenance_mode" {
  name = "maintenance-mode-permissions"
  role = aws_iam_role.maintenance_mode.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "WAFManagement"
        Effect = "Allow"
        Action = [
          "wafv2:CreateWebACL",
          "wafv2:UpdateWebACL",
          "wafv2:DeleteWebACL",
          "wafv2:GetWebACL",
          "wafv2:ListWebACLs",
          "wafv2:AssociateWebACL",
          "wafv2:DisassociateWebACL",
          "wafv2:CreateIPSet",
          "wafv2:UpdateIPSet",
          "wafv2:DeleteIPSet",
          "wafv2:GetIPSet",
          "wafv2:ListIPSets",
          "wafv2:CreateRuleGroup",
          "wafv2:UpdateRuleGroup",
          "wafv2:DeleteRuleGroup",
          "wafv2:GetRuleGroup",
          "wafv2:ListRuleGroups",
          "wafv2:ListTagsForResource",
          "wafv2:TagResource",
          "wafv2:UntagResource"
        ]
        Resource = "*"
      },
      {
        Sid    = "SSMParameterManagement"
        Effect = "Allow"
        Action = [
          "ssm:PutParameter",
          "ssm:GetParameter",
          "ssm:DeleteParameter",
          "ssm:AddTagsToResource",
          "ssm:ListTagsForResource"
        ]
        Resource = "arn:aws:ssm:*:*:parameter/maintenance-mode/*"
      },
      {
        Sid    = "CloudWatchAlarms"
        Effect = "Allow"
        Action = [
          "cloudwatch:PutMetricAlarm",
          "cloudwatch:DeleteAlarms",
          "cloudwatch:DescribeAlarms",
          "cloudwatch:ListTagsForResource",
          "cloudwatch:TagResource"
        ]
        Resource = "*"
        Condition = {
          StringEquals = {
            "aws:ResourceTag/Purpose" = "maintenance-mode"
          }
        }
      },
      {
        Sid    = "CloudWatchAlarmsCreate"
        Effect = "Allow"
        Action = [
          "cloudwatch:PutMetricAlarm"
        ]
        Resource = "*"
      }
    ]
  })
}

###############################################################################
# Outputs
###############################################################################

output "role_arn" {
  description = "ARN of the MaintenanceMode IAM role"
  value       = aws_iam_role.maintenance_mode.arn
}

output "role_name" {
  description = "Name of the MaintenanceMode IAM role"
  value       = aws_iam_role.maintenance_mode.name
}
