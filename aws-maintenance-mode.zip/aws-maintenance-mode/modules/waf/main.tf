###############################################################################
# AWS WAF Maintenance Mode Module - Main Configuration
###############################################################################

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

###############################################################################
# Local Variables
###############################################################################

locals {
  name_prefix = "${var.project_name}-${var.environment}"

  # Use custom HTML if provided, otherwise generate from template
  maintenance_html = var.custom_maintenance_html != "" ? var.custom_maintenance_html : templatefile(
    "${path.module}/templates/maintenance.html.tftpl",
    {
      title   = var.maintenance_page_title
      message = var.maintenance_page_message
      eta     = var.maintenance_page_eta
    }
  )

  # Combine all resource ARNs for association
  regional_resource_arns = concat(var.alb_arns, var.api_gateway_arns)

  common_tags = merge(
    {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "terraform"
      Purpose     = "maintenance-mode"
    },
    var.tags
  )
}

###############################################################################
# IP Sets - Internal Team Whitelisting
###############################################################################

resource "aws_wafv2_ip_set" "internal_ipv4" {
  name               = "${local.name_prefix}-internal-ipv4"
  description        = "Internal team IPv4 addresses that bypass maintenance mode"
  scope              = var.waf_scope
  ip_address_version = "IPV4"
  addresses          = var.internal_ipv4_cidrs

  tags = local.common_tags
}

resource "aws_wafv2_ip_set" "internal_ipv6" {
  count = length(var.internal_ipv6_cidrs) > 0 ? 1 : 0

  name               = "${local.name_prefix}-internal-ipv6"
  description        = "Internal team IPv6 addresses that bypass maintenance mode"
  scope              = var.waf_scope
  ip_address_version = "IPV6"
  addresses          = var.internal_ipv6_cidrs

  tags = local.common_tags
}

###############################################################################
# WAF Web ACL - Maintenance Mode Logic
###############################################################################

resource "aws_wafv2_web_acl" "maintenance" {
  name        = "${local.name_prefix}-waf"
  description = "WAF Web ACL for maintenance mode control. When maintenance is enabled, blocks external traffic and allows internal team."
  scope       = var.waf_scope

  # Default action changes based on maintenance mode
  # When maintenance OFF: Allow all traffic
  # When maintenance ON: Block all traffic (with exceptions in rules)
  default_action {
    dynamic "allow" {
      for_each = var.maintenance_enabled ? [] : [1]
      content {}
    }

    dynamic "block" {
      for_each = var.maintenance_enabled ? [1] : []
      content {
        custom_response {
          response_code            = 503
          custom_response_body_key = "maintenance-page"

          response_header {
            name  = "Retry-After"
            value = tostring(var.retry_after_seconds)
          }

          response_header {
            name  = "Cache-Control"
            value = "no-store, no-cache, must-revalidate, max-age=0"
          }

          response_header {
            name  = "X-Maintenance-Mode"
            value = "active"
          }
        }
      }
    }
  }

  # Custom response body - the maintenance page HTML
  custom_response_body {
    key          = "maintenance-page"
    content      = local.maintenance_html
    content_type = "TEXT_HTML"
  }

  ###########################################################################
  # Rule 1: Allow internal team IPv4 (highest priority)
  ###########################################################################
  dynamic "rule" {
    for_each = var.maintenance_enabled ? [1] : []
    content {
      name     = "allow-internal-ipv4"
      priority = 1

      override_action {
        none {}
      }

      statement {
        rule_group_reference_statement {
          arn = aws_wafv2_rule_group.allow_internal.arn
        }
      }

      visibility_config {
        sampled_requests_enabled   = true
        cloudwatch_metrics_enabled = true
        metric_name                = "${local.name_prefix}-allow-internal-ipv4"
      }
    }
  }

  ###########################################################################
  # Rule 2: Allow bypass header (for health checks, CI/CD)
  ###########################################################################
  dynamic "rule" {
    for_each = var.maintenance_enabled && var.bypass_header_value != "" ? [1] : []
    content {
      name     = "allow-bypass-header"
      priority = 2

      action {
        allow {}
      }

      statement {
        byte_match_statement {
          search_string = var.bypass_header_value
          field_to_match {
            single_header {
              name = lower(var.bypass_header_name)
            }
          }
          text_transformation {
            priority = 0
            type     = "NONE"
          }
          positional_constraint = "EXACTLY"
        }
      }

      visibility_config {
        sampled_requests_enabled   = true
        cloudwatch_metrics_enabled = true
        metric_name                = "${local.name_prefix}-allow-bypass"
      }
    }
  }

  ###########################################################################
  # Rule 3: Rate limiting (optional, protection during maintenance)
  ###########################################################################
  dynamic "rule" {
    for_each = var.rate_limit_enabled ? [1] : []
    content {
      name     = "rate-limit"
      priority = 10

      action {
        block {
          custom_response {
            response_code = 429
          }
        }
      }

      statement {
        rate_based_statement {
          limit              = var.rate_limit_value
          aggregate_key_type = "IP"
        }
      }

      visibility_config {
        sampled_requests_enabled   = true
        cloudwatch_metrics_enabled = true
        metric_name                = "${local.name_prefix}-rate-limit"
      }
    }
  }

  visibility_config {
    sampled_requests_enabled   = true
    cloudwatch_metrics_enabled = true
    metric_name                = "${local.name_prefix}-waf"
  }

  tags = local.common_tags
}

###############################################################################
# Rule Group - Allow Internal IPs
###############################################################################

resource "aws_wafv2_rule_group" "allow_internal" {
  name        = "${local.name_prefix}-allow-internal"
  description = "Rule group to allow internal team IPs during maintenance"
  scope       = var.waf_scope
  capacity    = 50

  rule {
    name     = "allow-ipv4"
    priority = 1

    action {
      allow {}
    }

    statement {
      ip_set_reference_statement {
        arn = aws_wafv2_ip_set.internal_ipv4.arn
      }
    }

    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "${local.name_prefix}-internal-ipv4-match"
    }
  }

  dynamic "rule" {
    for_each = length(var.internal_ipv6_cidrs) > 0 ? [1] : []
    content {
      name     = "allow-ipv6"
      priority = 2

      action {
        allow {}
      }

      statement {
        ip_set_reference_statement {
          arn = aws_wafv2_ip_set.internal_ipv6[0].arn
        }
      }

      visibility_config {
        sampled_requests_enabled   = true
        cloudwatch_metrics_enabled = true
        metric_name                = "${local.name_prefix}-internal-ipv6-match"
      }
    }
  }

  visibility_config {
    sampled_requests_enabled   = true
    cloudwatch_metrics_enabled = true
    metric_name                = "${local.name_prefix}-allow-internal-group"
  }

  tags = local.common_tags
}

###############################################################################
# WAF Associations - Attach to Resources
###############################################################################

# Associate with ALBs and API Gateways (REGIONAL scope)
resource "aws_wafv2_web_acl_association" "regional" {
  for_each = var.waf_scope == "REGIONAL" ? toset(local.regional_resource_arns) : toset([])

  resource_arn = each.value
  web_acl_arn  = aws_wafv2_web_acl.maintenance.arn
}

###############################################################################
# CloudWatch Alarms (optional monitoring)
###############################################################################

resource "aws_cloudwatch_metric_alarm" "maintenance_blocked_requests" {
  count = var.maintenance_enabled ? 1 : 0

  alarm_name          = "${local.name_prefix}-blocked-requests-high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "BlockedRequests"
  namespace           = "AWS/WAFV2"
  period              = 300
  statistic           = "Sum"
  threshold           = 10000
  alarm_description   = "High number of blocked requests during maintenance mode"

  dimensions = {
    WebACL = aws_wafv2_web_acl.maintenance.name
    Region = var.waf_scope == "CLOUDFRONT" ? "Global" : data.aws_region.current.id
    Rule   = "ALL"
  }

  tags = local.common_tags
}

data "aws_region" "current" {}

###############################################################################
# SSM Parameter - Store maintenance state for external tools
###############################################################################

resource "aws_ssm_parameter" "maintenance_state" {
  name        = "/${var.project_name}/${var.environment}/maintenance-enabled"
  description = "Current maintenance mode state"
  type        = "String"
  value       = var.maintenance_enabled ? "true" : "false"

  tags = local.common_tags
}
