###############################################################################
# AWS WAF Maintenance Mode Module - Outputs
###############################################################################

output "web_acl_id" {
  description = "The ID of the WAF Web ACL"
  value       = aws_wafv2_web_acl.maintenance.id
}

output "web_acl_arn" {
  description = "The ARN of the WAF Web ACL"
  value       = aws_wafv2_web_acl.maintenance.arn
}

output "web_acl_name" {
  description = "The name of the WAF Web ACL"
  value       = aws_wafv2_web_acl.maintenance.name
}

output "web_acl_capacity" {
  description = "Web ACL capacity units used"
  value       = aws_wafv2_web_acl.maintenance.capacity
}

output "ipv4_ip_set_id" {
  description = "The ID of the internal team IPv4 IP set"
  value       = aws_wafv2_ip_set.internal_ipv4.id
}

output "ipv4_ip_set_arn" {
  description = "The ARN of the internal team IPv4 IP set"
  value       = aws_wafv2_ip_set.internal_ipv4.arn
}

output "ipv6_ip_set_id" {
  description = "The ID of the internal team IPv6 IP set (if created)"
  value       = length(aws_wafv2_ip_set.internal_ipv6) > 0 ? aws_wafv2_ip_set.internal_ipv6[0].id : null
}

output "maintenance_enabled" {
  description = "Current state of maintenance mode"
  value       = var.maintenance_enabled
}

output "ssm_parameter_name" {
  description = "SSM Parameter name storing maintenance state"
  value       = aws_ssm_parameter.maintenance_state.name
}

output "rule_group_arn" {
  description = "ARN of the internal team allow rule group"
  value       = aws_wafv2_rule_group.allow_internal.arn
}
