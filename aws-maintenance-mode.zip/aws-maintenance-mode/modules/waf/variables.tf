###############################################################################
# AWS WAF Maintenance Mode Module - Variables
###############################################################################

variable "maintenance_enabled" {
  type        = bool
  default     = false
  description = "Toggle maintenance mode ON (true) or OFF (false). When ON, external users see the maintenance page while internal IPs are allowed through."
}

variable "project_name" {
  type        = string
  default     = "maintenance-mode"
  description = "Project name used for naming AWS resources."
}

variable "environment" {
  type        = string
  default     = "production"
  description = "Environment name (e.g., production, staging, dev)."
}

variable "internal_ipv4_cidrs" {
  type        = list(string)
  description = "List of IPv4 CIDR ranges for internal team (office IPs, VPN IPs). These IPs will bypass maintenance mode."
  default     = []

  validation {
    condition     = alltrue([for cidr in var.internal_ipv4_cidrs : can(cidrhost(cidr, 0))])
    error_message = "All entries must be valid IPv4 CIDR notation (e.g., 203.0.113.0/24)."
  }
}

variable "internal_ipv6_cidrs" {
  type        = list(string)
  description = "List of IPv6 CIDR ranges for internal team. These IPs will bypass maintenance mode."
  default     = []
}

variable "waf_scope" {
  type        = string
  default     = "REGIONAL"
  description = "WAF scope: CLOUDFRONT (for CloudFront distributions, must be us-east-1) or REGIONAL (for ALB, API Gateway, AppSync)."

  validation {
    condition     = contains(["CLOUDFRONT", "REGIONAL"], var.waf_scope)
    error_message = "WAF scope must be either CLOUDFRONT or REGIONAL."
  }
}

variable "maintenance_page_title" {
  type        = string
  default     = "Scheduled Maintenance"
  description = "Title shown on the maintenance page."
}

variable "maintenance_page_message" {
  type        = string
  default     = "We're performing scheduled maintenance to improve your experience. We apologize for the inconvenience and will be back shortly."
  description = "Message shown on the maintenance page."
}

variable "maintenance_page_eta" {
  type        = string
  default     = "We expect to be back within 2 hours."
  description = "Estimated time to completion shown on the maintenance page."
}

variable "retry_after_seconds" {
  type        = number
  default     = 3600
  description = "Value for the Retry-After response header (in seconds). Tells browsers/crawlers when to retry."
}

variable "custom_maintenance_html" {
  type        = string
  default     = ""
  description = "Optional: Provide your own custom maintenance page HTML. If empty, the default template is used."
}

variable "cloudfront_distribution_arns" {
  type        = list(string)
  default     = []
  description = "List of CloudFront distribution ARNs to associate with the WAF Web ACL (only for CLOUDFRONT scope)."
}

variable "alb_arns" {
  type        = list(string)
  default     = []
  description = "List of ALB ARNs to associate with the WAF Web ACL (only for REGIONAL scope)."
}

variable "api_gateway_arns" {
  type        = list(string)
  default     = []
  description = "List of API Gateway stage ARNs to associate with the WAF Web ACL (only for REGIONAL scope)."
}

variable "rate_limit_enabled" {
  type        = bool
  default     = false
  description = "Enable rate limiting rule to protect during maintenance (prevents DDoS while in maintenance)."
}

variable "rate_limit_value" {
  type        = number
  default     = 2000
  description = "Maximum requests per 5-minute period per IP (if rate limiting is enabled)."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Additional tags to apply to all resources."
}

variable "bypass_header_name" {
  type        = string
  default     = "X-Maintenance-Bypass"
  description = "Custom header name that can be used to bypass maintenance mode (for CI/CD pipelines, health checks)."
}

variable "bypass_header_value" {
  type        = string
  default     = ""
  sensitive   = true
  description = "Secret value for the bypass header. If empty, header bypass is disabled."
}
