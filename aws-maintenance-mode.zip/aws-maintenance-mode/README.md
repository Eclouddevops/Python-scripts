# AWS Maintenance Mode - WAF-Based Solution

A production-ready Terraform module that deploys AWS WAF-based maintenance mode across multiple AWS accounts and services (ECS, CloudFront, Lambda, EC2).

**Key Features:**
- One-command toggle (`./scripts/toggle.sh on/off`)
- Activates in < 30 seconds (no DNS propagation, no redeployment)
- Internal team bypasses maintenance via IP whitelisting
- Works across CloudFront, ALB (ECS/EC2), and API Gateway (Lambda)
- Multi-account support with cross-account IAM roles
- Optional bypass header for health checks and CI/CD
- Slack notifications when maintenance mode changes

---

## Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                    Central/Management Account                    │
│                                                                  │
│  Terraform runs here → assumes roles in target accounts          │
│  SSM Parameter: /maintenance-mode/prod/maintenance-enabled       │
└──────────────────────────┬───────────────────────────────────────┘
                           │ Cross-Account Role Assumption
          ┌────────────────┼────────────────────┐
          │                │                     │
   ┌──────▼──────┐  ┌─────▼──────┐  ┌──────────▼──────┐
   │  Account A  │  │  Account B │  │   Account C     │
   │  CloudFront │  │  ECS (ALB) │  │  Lambda (APIGW) │
   │             │  │  EC2 (ALB) │  │                  │
   │  WAF WebACL │  │  WAF WebACL│  │  WAF WebACL     │
   │ (CLOUDFRONT)│  │ (REGIONAL) │  │  (REGIONAL)     │
   └─────────────┘  └────────────┘  └─────────────────┘
```

**How it works:**
1. When `maintenance_enabled = true`:
   - WAF default action changes to **BLOCK** with a custom 503 response (maintenance page)
   - A rule group **allows** traffic from whitelisted internal IPs
   - Optional bypass header allows health checks through

2. When `maintenance_enabled = false`:
   - WAF default action is **ALLOW** — all traffic passes through normally
   - No rules are active (zero impact on production traffic)

---

## Directory Structure

```
aws-maintenance-mode/
├── modules/
│   ├── waf/                          # Core WAF module
│   │   ├── main.tf                   # WAF Web ACL, IP sets, rules
│   │   ├── variables.tf              # Module inputs
│   │   ├── outputs.tf                # Module outputs
│   │   └── templates/
│   │       └── maintenance.html.tftpl  # Maintenance page template
│   └── iam-role/                     # IAM role for target accounts
│       └── main.tf                   # Role + policy
├── environments/
│   ├── dev/                          # Dev environment config
│   └── prod/                         # Production environment config
│       ├── main.tf                   # Module invocations per account
│       ├── providers.tf              # Multi-account provider config
│       ├── variables.tf              # Environment variables
│       ├── outputs.tf                # Environment outputs
│       └── terraform.tfvars.example  # Example configuration
├── scripts/
│   └── toggle.sh                     # Quick toggle script
└── README.md                         # This file
```

---

## Prerequisites

1. **Terraform >= 1.5.0** installed
2. **AWS CLI v2** configured with credentials for the central account
3. **S3 bucket** for Terraform state (update `backend` block in `providers.tf`)
4. **VPN or static office IPs** for internal team access
5. **ALB** in front of ECS/EC2 services (WAF cannot attach directly to instances)
6. **API Gateway** in front of Lambda functions (WAF attaches to API Gateway stages)

---

## Setup Guide

### Step 1: Deploy IAM Roles in Each Target Account

First, create the `MaintenanceModeRole` in each account that hosts your services.

```bash
# For each target account, run:
cd modules/iam-role

# Configure AWS CLI for the target account
export AWS_PROFILE=target-account-profile

terraform init
terraform apply \
  -var="central_account_id=000000000000" \
  -var="role_name=MaintenanceModeRole" \
  -var="external_id=maintenance-mode-2024-secure"
```

Repeat for each account (CloudFront, ECS, Lambda, EC2).

### Step 2: Configure Your Environment

```bash
cd environments/prod

# Copy the example config
cp terraform.tfvars.example terraform.tfvars

# Edit with your actual values
vi terraform.tfvars
```

**Critical values to update:**
- `cloudfront_account_id`, `ecs_account_id`, `lambda_account_id`, `ec2_account_id`
- `internal_ipv4_cidrs` — your office/VPN IP ranges
- `ecs_alb_arns`, `ec2_alb_arns`, `lambda_api_gateway_arns`, `cloudfront_distribution_arns`
- `bypass_header_value` — generate a strong random token

### Step 3: Update Terraform Backend

Edit `environments/prod/providers.tf` and update the S3 backend configuration:

```hcl
backend "s3" {
  bucket         = "your-actual-terraform-state-bucket"
  key            = "maintenance-mode/prod/terraform.tfstate"
  region         = "us-east-1"
  dynamodb_table = "your-terraform-lock-table"
  encrypt        = true
}
```

### Step 4: Initialize and Deploy (Normal Mode)

```bash
cd environments/prod
terraform init
terraform plan
terraform apply    # Deploys with maintenance_enabled = false
```

---

## Usage

### Enable Maintenance Mode

```bash
# Interactive (with confirmation prompt)
./scripts/toggle.sh on

# Non-interactive (for CI/CD)
./scripts/toggle.sh on --auto-approve

# For a specific environment
./scripts/toggle.sh on --env dev
```

### Disable Maintenance Mode

```bash
# Interactive
./scripts/toggle.sh off

# Non-interactive
./scripts/toggle.sh off --auto-approve
```

### Check Status

```bash
./scripts/toggle.sh status
```

### Direct Terraform Commands

```bash
# Enable
cd environments/prod
terraform apply -var="maintenance_enabled=true" -auto-approve

# Disable
terraform apply -var="maintenance_enabled=false" -auto-approve
```

---

## Testing Guide

### Test 1: Local Validation (No AWS Access Needed)

```bash
# Validate Terraform configuration
cd environments/prod
terraform init -backend=false    # Skip backend for local testing
terraform validate               # Check syntax and logic

# Format check
terraform fmt -check -recursive ../../
```

### Test 2: Plan Without Applying

```bash
# See what would be created (requires AWS access)
terraform plan -var="maintenance_enabled=false"

# See what changes when enabling maintenance
terraform plan -var="maintenance_enabled=true"
```

### Test 3: Deploy to a Single Dev Account First

Create a minimal dev environment:

```bash
cd environments/dev

# Use a single account for testing
terraform init
terraform apply -var="maintenance_enabled=false"

# Now test enabling
terraform apply -var="maintenance_enabled=true"
```

### Test 4: Verify Maintenance Page Works

Once deployed, test with `curl`:

```bash
# From EXTERNAL IP (should see 503 + maintenance page)
curl -v https://your-website.com
# Expected: HTTP/1.1 503 Service Temporarily Unavailable
# Expected: Retry-After: 3600
# Expected: HTML maintenance page in body

# From INTERNAL IP (VPN) (should see normal site)
curl -v https://your-website.com
# Expected: HTTP/1.1 200 OK (normal response)

# Using bypass header (should see normal site from anywhere)
curl -v -H "X-Maintenance-Bypass: your-secret-token" https://your-website.com
# Expected: HTTP/1.1 200 OK (normal response)
```

### Test 5: Verify IP Whitelisting

```bash
# Check your current public IP
curl -s ifconfig.me

# Ensure your IP is in the internal_ipv4_cidrs list
# Connect to VPN, then test:
curl -s -o /dev/null -w "%{http_code}" https://your-website.com
# Expected: 200 (you're on a whitelisted IP)

# Disconnect from VPN and test again:
curl -s -o /dev/null -w "%{http_code}" https://your-website.com
# Expected: 503 (you're now on an external IP)
```

### Test 6: Verify WAF Metrics in CloudWatch

```bash
# Check blocked requests count
aws cloudwatch get-metric-statistics \
  --namespace AWS/WAFV2 \
  --metric-name BlockedRequests \
  --dimensions Name=WebACL,Value=maintenance-mode-production-waf Name=Region,Value=us-east-1 Name=Rule,Value=ALL \
  --start-time $(date -u -d '1 hour ago' '+%Y-%m-%dT%H:%M:%S') \
  --end-time $(date -u '+%Y-%m-%dT%H:%M:%S') \
  --period 300 \
  --statistics Sum
```

### Test 7: End-to-End Toggle Test

```bash
# 1. Enable maintenance
./scripts/toggle.sh on --auto-approve

# 2. Wait 30 seconds for propagation
sleep 30

# 3. Test external access (should be blocked)
EXTERNAL_STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://your-website.com)
echo "External status: $EXTERNAL_STATUS"  # Should be 503

# 4. Test internal access via bypass header
INTERNAL_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "X-Maintenance-Bypass: your-token" https://your-website.com)
echo "Internal status: $INTERNAL_STATUS"  # Should be 200

# 5. Disable maintenance
./scripts/toggle.sh off --auto-approve

# 6. Wait 30 seconds
sleep 30

# 7. Verify normal access restored
NORMAL_STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://your-website.com)
echo "Normal status: $NORMAL_STATUS"  # Should be 200
```

### Test 8: Simulate with AWS WAF Test (Sampled Requests)

```bash
# View sampled requests to see what WAF is doing
aws wafv2 get-sampled-requests \
  --web-acl-arn "arn:aws:wafv2:us-east-1:ACCOUNT_ID:regional/webacl/maintenance-mode-production-waf/ID" \
  --rule-metric-name "maintenance-mode-production-waf" \
  --scope REGIONAL \
  --time-window '{"StartTime":"2024-01-01T00:00:00Z","EndTime":"2024-12-31T23:59:59Z"}' \
  --max-items 10
```

---

## Slack Notifications (Optional)

Set the `SLACK_WEBHOOK_URL` environment variable to receive notifications:

```bash
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"
./scripts/toggle.sh on
# → Sends: "🔧 Maintenance Mode ENABLED for production by username"
```

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| 503 for internal team | IP not in whitelist | Add your IP to `internal_ipv4_cidrs` and re-apply |
| Still showing site after enabling | WAF propagation delay | Wait 30-60 seconds; check WAF association |
| Terraform plan shows no changes | Already in desired state | Run `terraform refresh` to sync state |
| Cross-account assume role fails | Missing IAM role | Deploy `modules/iam-role` in target account |
| WAF capacity exceeded | Too many rules | Reduce rule complexity or request limit increase |

---

## Costs

| Component | Monthly Cost |
|-----------|-------------|
| WAF Web ACL | $5.00 per ACL |
| WAF Rules | $1.00 per rule |
| WAF Requests | $0.60 per 1M requests |
| SSM Parameter | Free (standard tier) |
| CloudWatch Alarm | $0.10 per alarm |
| **Per Account Total** | **~$7-12/month** |
| **4 Accounts Total** | **~$28-48/month** |

---

## Security Considerations

1. **Bypass token**: Store in AWS Secrets Manager or use environment variables. Never commit to git.
2. **External ID**: Use for cross-account role assumption to prevent confused deputy attacks.
3. **IP whitelisting**: Keep the IP list minimal. Use VPN CIDR ranges, not individual IPs.
4. **State file**: Encrypt the Terraform state bucket with SSE-KMS.
5. **Audit trail**: All WAF changes are logged in CloudTrail.

---

## FAQ

**Q: How quickly does maintenance mode activate?**
A: WAF rule changes propagate in 15-30 seconds globally.

**Q: Can I use different maintenance pages per service?**
A: Yes — pass `custom_maintenance_html` or different `maintenance_page_*` variables per module invocation.

**Q: What if I don't have a VPN?**
A: Use the bypass header approach. Team members can access via a bookmarklet or browser extension that adds the header.

**Q: Does this work with WebSocket connections?**
A: WAF evaluates the initial HTTP request. Existing WebSocket connections won't be interrupted, but new ones will be blocked.

**Q: Can I schedule maintenance windows?**
A: Yes — use AWS EventBridge with a Lambda function that runs `terraform apply` at scheduled times, or integrate with your CI/CD pipeline.
