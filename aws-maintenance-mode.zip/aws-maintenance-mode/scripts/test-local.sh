#!/bin/bash
###############################################################################
# Local Test Script - Validate Terraform Configuration
#
# This script tests the Terraform module locally without needing AWS access.
# Use this to verify syntax, formatting, and module structure.
#
# Usage: ./scripts/test-local.sh
###############################################################################

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

PASS=0
FAIL=0

test_pass() {
    echo -e "  ${GREEN}PASS${NC}: $1"
    PASS=$((PASS + 1))
}

test_fail() {
    echo -e "  ${RED}FAIL${NC}: $1"
    FAIL=$((FAIL + 1))
}

echo "==========================================="
echo " Maintenance Mode Module - Local Tests"
echo "==========================================="
echo ""

###############################################################################
# Test 1: Check directory structure
###############################################################################
echo "Test 1: Directory Structure"

REQUIRED_FILES=(
    "modules/waf/main.tf"
    "modules/waf/variables.tf"
    "modules/waf/outputs.tf"
    "modules/waf/templates/maintenance.html.tftpl"
    "modules/iam-role/main.tf"
    "environments/dev/main.tf"
    "environments/prod/main.tf"
    "environments/prod/providers.tf"
    "environments/prod/variables.tf"
    "environments/prod/outputs.tf"
    "scripts/toggle.sh"
    "README.md"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$PROJECT_ROOT/$file" ]; then
        test_pass "$file exists"
    else
        test_fail "$file missing"
    fi
done

echo ""

###############################################################################
# Test 2: Terraform Format Check
###############################################################################
echo "Test 2: Terraform Format"

if command -v terraform &> /dev/null; then
    cd "$PROJECT_ROOT"
    if terraform fmt -check -recursive . 2>/dev/null; then
        test_pass "All .tf files are properly formatted"
    else
        test_fail "Some .tf files need formatting (run: terraform fmt -recursive .)"
    fi
else
    echo -e "  ${YELLOW}SKIP${NC}: terraform not installed"
fi

echo ""

###############################################################################
# Test 3: Terraform Validate (modules)
###############################################################################
echo "Test 3: Terraform Validate"

if command -v terraform &> /dev/null; then
    # Validate WAF module
    cd "$PROJECT_ROOT/modules/waf"
    if terraform init -backend=false -input=false > /dev/null 2>&1; then
        if terraform validate > /dev/null 2>&1; then
            test_pass "modules/waf validates successfully"
        else
            test_fail "modules/waf validation failed"
            terraform validate
        fi
    else
        test_fail "modules/waf init failed"
    fi

    # Validate dev environment
    cd "$PROJECT_ROOT/environments/dev"
    if terraform init -backend=false -input=false > /dev/null 2>&1; then
        if terraform validate > /dev/null 2>&1; then
            test_pass "environments/dev validates successfully"
        else
            test_fail "environments/dev validation failed"
            terraform validate
        fi
    else
        test_fail "environments/dev init failed"
    fi
else
    echo -e "  ${YELLOW}SKIP${NC}: terraform not installed"
fi

echo ""

###############################################################################
# Test 4: Maintenance HTML Template
###############################################################################
echo "Test 4: Maintenance Page Template"

TEMPLATE="$PROJECT_ROOT/modules/waf/templates/maintenance.html.tftpl"

if grep -q "<!DOCTYPE html>" "$TEMPLATE"; then
    test_pass "HTML template has DOCTYPE"
else
    test_fail "HTML template missing DOCTYPE"
fi

if grep -q '<meta http-equiv="refresh"' "$TEMPLATE"; then
    test_pass "HTML template has auto-refresh"
else
    test_fail "HTML template missing auto-refresh"
fi

if grep -q '${title}' "$TEMPLATE"; then
    test_pass "HTML template has title variable"
else
    test_fail "HTML template missing title variable"
fi

if grep -q '${message}' "$TEMPLATE"; then
    test_pass "HTML template has message variable"
else
    test_fail "HTML template missing message variable"
fi

echo ""

###############################################################################
# Test 5: Toggle script validation
###############################################################################
echo "Test 5: Toggle Script"

TOGGLE="$PROJECT_ROOT/scripts/toggle.sh"

if [ -x "$TOGGLE" ]; then
    test_pass "toggle.sh is executable"
else
    test_fail "toggle.sh is not executable"
fi

if grep -q "set -euo pipefail" "$TOGGLE"; then
    test_pass "toggle.sh has strict mode"
else
    test_fail "toggle.sh missing strict mode"
fi

if grep -q "enable_maintenance\|disable_maintenance\|check_status" "$TOGGLE"; then
    test_pass "toggle.sh has all required functions"
else
    test_fail "toggle.sh missing functions"
fi

echo ""

###############################################################################
# Test 6: Security checks
###############################################################################
echo "Test 6: Security Checks"

if [ -f "$PROJECT_ROOT/.gitignore" ]; then
    if grep -q "terraform.tfvars" "$PROJECT_ROOT/.gitignore"; then
        test_pass ".gitignore excludes terraform.tfvars"
    else
        test_fail ".gitignore missing terraform.tfvars exclusion"
    fi

    if grep -q "*.tfstate" "$PROJECT_ROOT/.gitignore"; then
        test_pass ".gitignore excludes state files"
    else
        test_fail ".gitignore missing state file exclusion"
    fi
else
    test_fail ".gitignore file missing"
fi

# Check that no secrets are hardcoded
if grep -rn "AKIA\|aws_secret_access_key\s*=\s*\"[^\"]\+" "$PROJECT_ROOT" --include="*.tf" 2>/dev/null; then
    test_fail "Potential secrets found in .tf files!"
else
    test_pass "No hardcoded secrets in .tf files"
fi

echo ""

###############################################################################
# Summary
###############################################################################
echo "==========================================="
echo " Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "==========================================="

if [ $FAIL -gt 0 ]; then
    exit 1
fi
