#!/bin/bash
###############################################################################
# Maintenance Mode Toggle Script
#
# Usage:
#   ./toggle.sh on              # Enable maintenance mode
#   ./toggle.sh off             # Disable maintenance mode
#   ./toggle.sh status          # Check current status
#   ./toggle.sh on --env dev    # Enable for specific environment
#
# Prerequisites:
#   - AWS CLI configured with access to the central/management account
#   - Terraform installed (>= 1.5.0)
#   - jq installed
###############################################################################

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
ENVIRONMENT="prod"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
AUTO_APPROVE=""
SLACK_WEBHOOK_URL="${SLACK_WEBHOOK_URL:-}"

###############################################################################
# Helper Functions
###############################################################################

usage() {
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  on       Enable maintenance mode (block external users)"
    echo "  off      Disable maintenance mode (allow all users)"
    echo "  status   Check current maintenance mode status"
    echo ""
    echo "Options:"
    echo "  --env <environment>    Target environment (default: prod)"
    echo "  --auto-approve         Skip confirmation prompt"
    echo "  --help                 Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 on                     # Enable maintenance, with confirmation"
    echo "  $0 off                    # Disable maintenance, with confirmation"
    echo "  $0 on --auto-approve      # Enable without confirmation (CI/CD)"
    echo "  $0 on --env dev           # Enable for dev environment"
    echo "  $0 status                 # Check current status"
    echo ""
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Send Slack notification (if webhook URL is configured)
notify_slack() {
    local message=$1
    local color=$2

    if [ -n "$SLACK_WEBHOOK_URL" ]; then
        curl -s -X POST "$SLACK_WEBHOOK_URL" \
            -H 'Content-Type: application/json' \
            -d "{
                \"attachments\": [{
                    \"color\": \"$color\",
                    \"text\": \"$message\",
                    \"footer\": \"Maintenance Mode | $(date -u '+%Y-%m-%d %H:%M:%S UTC')\"
                }]
            }" > /dev/null 2>&1 || true
        log_info "Slack notification sent"
    fi
}

confirm_action() {
    local action=$1
    if [ -n "$AUTO_APPROVE" ]; then
        return 0
    fi

    echo ""
    if [ "$action" == "on" ]; then
        echo -e "${YELLOW}WARNING: You are about to ENABLE maintenance mode.${NC}"
        echo "  - All external users will see the maintenance page"
        echo "  - Internal team (whitelisted IPs) can still access"
        echo "  - Environment: $ENVIRONMENT"
    else
        echo -e "${GREEN}You are about to DISABLE maintenance mode.${NC}"
        echo "  - All users will be able to access the site normally"
        echo "  - Environment: $ENVIRONMENT"
    fi

    echo ""
    read -p "Are you sure? (yes/no): " response
    if [[ "$response" != "yes" ]]; then
        log_warn "Aborted."
        exit 0
    fi
}

###############################################################################
# Main Commands
###############################################################################

enable_maintenance() {
    confirm_action "on"

    log_info "Enabling maintenance mode for environment: $ENVIRONMENT"
    echo ""

    cd "$PROJECT_ROOT/environments/$ENVIRONMENT"

    # Run Terraform apply with maintenance_enabled=true
    terraform apply \
        -var="maintenance_enabled=true" \
        -auto-approve \
        -compact-warnings

    if [ $? -eq 0 ]; then
        echo ""
        log_success "============================================="
        log_success "  MAINTENANCE MODE: ENABLED"
        log_success "============================================="
        log_success "  External users: BLOCKED (503 maintenance page)"
        log_success "  Internal team:  ALLOWED (via whitelisted IPs)"
        log_success "============================================="
        echo ""

        notify_slack ":wrench: *Maintenance Mode ENABLED* for \`$ENVIRONMENT\` by $(whoami)" "#ff9800"
    else
        log_error "Failed to enable maintenance mode!"
        notify_slack ":x: *Failed to enable maintenance mode* for \`$ENVIRONMENT\`" "#f44336"
        exit 1
    fi
}

disable_maintenance() {
    confirm_action "off"

    log_info "Disabling maintenance mode for environment: $ENVIRONMENT"
    echo ""

    cd "$PROJECT_ROOT/environments/$ENVIRONMENT"

    # Run Terraform apply with maintenance_enabled=false
    terraform apply \
        -var="maintenance_enabled=false" \
        -auto-approve \
        -compact-warnings

    if [ $? -eq 0 ]; then
        echo ""
        log_success "============================================="
        log_success "  MAINTENANCE MODE: DISABLED"
        log_success "============================================="
        log_success "  All users: ALLOWED (normal operation)"
        log_success "============================================="
        echo ""

        notify_slack ":white_check_mark: *Maintenance Mode DISABLED* for \`$ENVIRONMENT\` by $(whoami)" "#4caf50"
    else
        log_error "Failed to disable maintenance mode!"
        notify_slack ":x: *Failed to disable maintenance mode* for \`$ENVIRONMENT\`" "#f44336"
        exit 1
    fi
}

check_status() {
    log_info "Checking maintenance mode status for environment: $ENVIRONMENT"
    echo ""

    cd "$PROJECT_ROOT/environments/$ENVIRONMENT"

    # Check Terraform state
    local state_value
    state_value=$(terraform output -json maintenance_enabled 2>/dev/null || echo "unknown")

    if [ "$state_value" == "true" ]; then
        echo -e "  Status: ${RED}MAINTENANCE MODE ACTIVE${NC}"
        echo "  External users are seeing the maintenance page."
    elif [ "$state_value" == "false" ]; then
        echo -e "  Status: ${GREEN}NORMAL OPERATION${NC}"
        echo "  All users can access the site."
    else
        echo -e "  Status: ${YELLOW}UNKNOWN${NC}"
        echo "  Could not determine status. Run 'terraform init' first."
    fi

    echo ""

    # Also check SSM parameter if accessible
    local ssm_value
    ssm_value=$(aws ssm get-parameter \
        --name "/maintenance-mode/$ENVIRONMENT/maintenance-enabled" \
        --query "Parameter.Value" \
        --output text 2>/dev/null || echo "N/A")

    echo "  SSM Parameter Value: $ssm_value"
    echo ""
}

###############################################################################
# Parse Arguments
###############################################################################

COMMAND="${1:-help}"
shift || true

while [[ $# -gt 0 ]]; do
    case $1 in
        --env)
            ENVIRONMENT="$2"
            shift 2
            ;;
        --auto-approve)
            AUTO_APPROVE="true"
            shift
            ;;
        --help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

###############################################################################
# Validate Environment
###############################################################################

if [ ! -d "$PROJECT_ROOT/environments/$ENVIRONMENT" ]; then
    log_error "Environment '$ENVIRONMENT' not found at $PROJECT_ROOT/environments/$ENVIRONMENT"
    echo "Available environments:"
    ls "$PROJECT_ROOT/environments/"
    exit 1
fi

###############################################################################
# Execute Command
###############################################################################

case $COMMAND in
    on|enable)
        enable_maintenance
        ;;
    off|disable)
        disable_maintenance
        ;;
    status|check)
        check_status
        ;;
    help|--help|-h)
        usage
        ;;
    *)
        log_error "Unknown command: $COMMAND"
        usage
        exit 1
        ;;
esac
