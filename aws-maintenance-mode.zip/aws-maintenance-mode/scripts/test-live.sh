#!/bin/bash
###############################################################################
# Live Integration Test Script
#
# This script tests the actual deployed maintenance mode against a real endpoint.
# Run AFTER deploying the module to verify everything works end-to-end.
#
# Usage:
#   ./scripts/test-live.sh <website_url> [bypass_token]
#
# Examples:
#   ./scripts/test-live.sh https://myapp.example.com
#   ./scripts/test-live.sh https://myapp.example.com my-secret-bypass-token
###############################################################################

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

WEBSITE_URL="${1:-}"
BYPASS_TOKEN="${2:-}"
BYPASS_HEADER="X-Maintenance-Bypass"

if [ -z "$WEBSITE_URL" ]; then
    echo "Usage: $0 <website_url> [bypass_token]"
    echo "Example: $0 https://myapp.example.com my-bypass-token"
    exit 1
fi

PASS=0
FAIL=0

test_pass() {
    echo -e "  ${GREEN}PASS${NC}: $1"
    PASS=$((PASS + 1))
}

test_fail() {
    echo -e "  ${RED}FAIL${NC}: $1 (Got: $2)"
    FAIL=$((FAIL + 1))
}

echo ""
echo "==========================================="
echo " Maintenance Mode - Live Integration Tests"
echo "==========================================="
echo ""
echo "Target: $WEBSITE_URL"
echo "Bypass Token: ${BYPASS_TOKEN:+configured}${BYPASS_TOKEN:-not configured}"
echo ""

###############################################################################
# Detect current mode
###############################################################################
echo "--- Detecting current mode ---"
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$WEBSITE_URL" 2>/dev/null || echo "000")
echo "Current HTTP status: $HTTP_STATUS"
echo ""

if [ "$HTTP_STATUS" == "503" ]; then
    echo -e "${YELLOW}Maintenance mode appears to be ACTIVE${NC}"
    MODE="maintenance"
elif [ "$HTTP_STATUS" == "200" ] || [ "$HTTP_STATUS" == "301" ] || [ "$HTTP_STATUS" == "302" ]; then
    echo -e "${GREEN}Site appears to be in NORMAL mode${NC}"
    MODE="normal"
else
    echo -e "${RED}Unexpected status code: $HTTP_STATUS${NC}"
    MODE="unknown"
fi
echo ""

###############################################################################
# Tests when maintenance mode is ACTIVE
###############################################################################
if [ "$MODE" == "maintenance" ]; then
    echo "--- Testing Maintenance Mode Behavior ---"
    echo ""

    # Test 1: Should return 503
    echo "Test: External request returns 503"
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$WEBSITE_URL")
    if [ "$STATUS" == "503" ]; then
        test_pass "External request blocked with 503"
    else
        test_fail "Expected 503 for external request" "$STATUS"
    fi

    # Test 2: Response should contain maintenance page HTML
    echo "Test: Response contains maintenance page content"
    BODY=$(curl -s "$WEBSITE_URL")
    if echo "$BODY" | grep -qi "maintenance\|scheduled\|back soon"; then
        test_pass "Response contains maintenance page content"
    else
        test_fail "Response doesn't contain expected maintenance content" "unexpected body"
    fi

    # Test 3: Should have Retry-After header
    echo "Test: Response includes Retry-After header"
    RETRY_AFTER=$(curl -s -I "$WEBSITE_URL" | grep -i "retry-after" || echo "")
    if [ -n "$RETRY_AFTER" ]; then
        test_pass "Retry-After header present: $RETRY_AFTER"
    else
        test_fail "Retry-After header missing" "no header"
    fi

    # Test 4: Should have Cache-Control: no-store
    echo "Test: Response has no-cache headers"
    CACHE_CONTROL=$(curl -s -I "$WEBSITE_URL" | grep -i "cache-control" || echo "")
    if echo "$CACHE_CONTROL" | grep -qi "no-store\|no-cache"; then
        test_pass "Cache-Control prevents caching: $CACHE_CONTROL"
    else
        test_fail "Cache-Control header missing or wrong" "${CACHE_CONTROL:-none}"
    fi

    # Test 5: Bypass header should work
    if [ -n "$BYPASS_TOKEN" ]; then
        echo "Test: Bypass header allows access"
        BYPASS_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "$BYPASS_HEADER: $BYPASS_TOKEN" "$WEBSITE_URL")
        if [ "$BYPASS_STATUS" == "200" ] || [ "$BYPASS_STATUS" == "301" ] || [ "$BYPASS_STATUS" == "302" ]; then
            test_pass "Bypass header allows access (status: $BYPASS_STATUS)"
        else
            test_fail "Bypass header didn't work" "$BYPASS_STATUS"
        fi

        # Test 6: Wrong bypass token should still block
        echo "Test: Wrong bypass token is still blocked"
        WRONG_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "$BYPASS_HEADER: wrong-token" "$WEBSITE_URL")
        if [ "$WRONG_STATUS" == "503" ]; then
            test_pass "Wrong bypass token correctly blocked"
        else
            test_fail "Wrong token was not blocked" "$WRONG_STATUS"
        fi
    else
        echo -e "  ${YELLOW}SKIP${NC}: Bypass header tests (no token provided)"
    fi

    # Test 7: Different paths should all return 503
    echo "Test: Multiple paths return 503"
    PATHS=("/" "/api" "/health" "/login" "/dashboard")
    ALL_503=true
    for path in "${PATHS[@]}"; do
        PATH_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${WEBSITE_URL}${path}" 2>/dev/null || echo "000")
        if [ "$PATH_STATUS" != "503" ]; then
            ALL_503=false
            echo -e "    ${YELLOW}Path $path returned $PATH_STATUS instead of 503${NC}"
        fi
    done
    if [ "$ALL_503" == "true" ]; then
        test_pass "All paths correctly return 503"
    else
        test_fail "Some paths not returning 503" "see above"
    fi
fi

###############################################################################
# Tests when site is in NORMAL mode
###############################################################################
if [ "$MODE" == "normal" ]; then
    echo "--- Testing Normal Mode Behavior ---"
    echo ""

    # Test 1: Should return 200
    echo "Test: Site returns 200"
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$WEBSITE_URL")
    if [ "$STATUS" == "200" ] || [ "$STATUS" == "301" ] || [ "$STATUS" == "302" ]; then
        test_pass "Site accessible (status: $STATUS)"
    else
        test_fail "Unexpected status" "$STATUS"
    fi

    # Test 2: Should NOT have maintenance headers
    echo "Test: No maintenance headers present"
    MAINT_HEADER=$(curl -s -I "$WEBSITE_URL" | grep -i "x-maintenance-mode" || echo "")
    if [ -z "$MAINT_HEADER" ]; then
        test_pass "No X-Maintenance-Mode header (good)"
    else
        test_fail "X-Maintenance-Mode header found unexpectedly" "$MAINT_HEADER"
    fi

    echo ""
    echo -e "${BLUE}To test maintenance mode behavior:${NC}"
    echo "  1. Enable maintenance: ./scripts/toggle.sh on"
    echo "  2. Wait 30 seconds"
    echo "  3. Re-run this test: $0 $WEBSITE_URL $BYPASS_TOKEN"
fi

###############################################################################
# Summary
###############################################################################
echo ""
echo "==========================================="
echo " Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "==========================================="
echo ""

if [ $FAIL -gt 0 ]; then
    echo -e "${RED}Some tests failed. Check the output above.${NC}"
    exit 1
else
    echo -e "${GREEN}All tests passed!${NC}"
fi
